package com.capstone.ShowSeek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowSeekApplicationTests {

	@Test
	void contextLoads() {
	}

}
